
import doesnt_git_easier as git
from doesnt_git_easier import *


with git.commit(message = "testing"):
	
	with open("https://github.com/ryan-schreiber/doesnt-git-easier/test/README.md?ref=main", "w") as f:
		f.write("hello world")
		f.add()

